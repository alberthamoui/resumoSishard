#include <stdlib.h>
#include "point2d.h"
#include <math.h>

Point2D *point2D_new(double x, double y) {
    Point2D *p = malloc(sizeof(Point2D));
    p->x = x;
    p->y = y;
    return p;
}


void point2D_destroy(Point2D *p) {
    free(p);
}

double point2D_get_x(Point2D *p) {
    double x = p->x;
    return x;
}

double point2D_get_y(Point2D *p) {
    double y = p->y;
    // return 0;
    return y;
}

Point2D *point2D_add(Point2D *p1, Point2D *p2) {
    Point2D *p = point2D_new(p1->x + p2->x, p1->y + p2->y);
    // return NULL;
    return p;
}


double point2D_theta(Point2D *p1, Point2D *p2) {
    double theta = (p2->y - p1->y)/(p2->x - p1->x);
    return theta;
}

Point2D *point2D_scale(Point2D *p, double s) {
    p = point2D_new(p->x * s, p->y * s);
    return p;
}


