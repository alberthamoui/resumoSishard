#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

pthread_mutex_t mutex_soma;

struct soma_parcial_args {
    double *vetor;
    int start, end;
};

double soma = 0;

void *soma_parcial(void *_arg) {
    struct soma_parcial_args *spa = _arg;
    double local_soma = 0;

    for (int i = spa->start; i < spa->end; i++) {
        local_soma += spa->vetor[i];
    }
    
    pthread_mutex_lock(&mutex_soma);
    soma += local_soma;
    pthread_mutex_unlock(&mutex_soma);

    return NULL;
}

int main(int argc, char *argv[]) {
    int n;
    scanf("%d", &n);
    double *vetor = malloc(sizeof(double) * n);
    for (int i = 0; i < n; i++) {
        scanf("%lf", &vetor[i]);
    }

    pthread_t threads[4];
    struct soma_parcial_args args[4];
    int chunk_size = n / 4;

    pthread_mutex_init(&mutex_soma, NULL);

    for (int i = 0; i < 4; i++) {
        args[i].vetor = vetor;
        args[i].start = i * chunk_size;
        args[i].end = (i == 3) ? n : (i + 1) * chunk_size;
        pthread_create(&threads[i], NULL, soma_parcial, &args[i]);
    }

    for (int i = 0; i < 4; i++) {
        pthread_join(threads[i], NULL);
    }

    printf("Paralela: %lf\n", soma);

    soma = 0;
    struct soma_parcial_args aa;
    aa.vetor = vetor;
    aa.start = 0;
    aa.end = n;
    soma_parcial(&aa);
    printf("Sequencial: %lf\n", soma);

    free(vetor);
    pthread_mutex_destroy(&mutex_soma);
    return 0;
}
