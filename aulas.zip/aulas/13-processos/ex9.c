#include <sys/types.h>
#include <sys/wait.h> // Include for waitpid
#include <unistd.h>
#include <stdio.h>

int main() {
    pid_t pai;
    int status; // Variable to store the status of the child process
    
    int n = 3;

    for (int i = 0; i<n; i++){
        pai = fork();
        sleep(5);
        if (!pai){
            printf("Eu sou o filho %d com o PID %d, meu pai tem o PID %d\n", i+1, getpid(), getppid());
            return 0;
        }
    }

    for(int i = 0; i<n; i++){
        wait(&status);
    }
    return 0;
}