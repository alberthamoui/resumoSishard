#include <sys/types.h>
#include <sys/wait.h> // Include for waitpid
#include <unistd.h>
#include <stdio.h>

int main() {
    pid_t pai, p2,p3,p4,p5;
    int status; // Variable to store the status of the child process
    p2 = fork();
    if (!p2) {
        // P2
        printf("eu sou o P2 com o PID %d, meu pai tem o PID %d\n", getpid(), getppid());
        return 0;
    } else{
        // P1
        p3 = fork();
        if (!p3){
            // P3
            printf("eu sou o P3 com o PID %d, meu pai tem o PID %d\n", getpid(), getppid());
            p4 = fork();
            if (!p4){
                // P4
                printf("eu sou o P4 com o PID %d, meu pai tem o PID %d\n", getpid(), getppid());
                return 0;
            }else{
                p5 = fork();
                if (!p5){
                    // P5
                    printf("eu sou o P5 com o PID %d, meu pai tem o PID %d\n", getpid(), getppid());
                    return 0;
                }
                waitpid(p4, &status, 0); // Correct function to wait for third child
                waitpid(p5, &status, 0); // Correct function to wait for fourth child
                return 0;
            }
        }else{
            // P1
                pai = getpid();
                printf("eu sou o P1 com o PID %d\n", pai);
                waitpid(p2, &status, 0); // Correct function to wait for first child
                waitpid(p3, &status, 0); // Correct function to wait for second child
                return 0;
        }
    }
    return 0;
}