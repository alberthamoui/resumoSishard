#include <sys/types.h>
#include <sys/wait.h> // Include for waitpid
#include <unistd.h>
#include <stdio.h>

int main() {
    pid_t pai, f1, f2,f3,f4;
    int n1 = 5;
    int n2 = 4;
    int status; // Variable to store the status of the child process
    int variavel;
    f1 = fork();
    if (!f1) {
        // First child process
        variavel = n1-n2;
        printf("eu sou o primeiro processo filho %d\tvariavel %d\n", getpid(), variavel);
    } else{
        f2 = fork();
        if (f2 == 0) {
            // Second child process
            variavel = n1+n2;
            printf("eu sou o segundo processo filho %d\tvariavel %d\n", getpid(), variavel);
        } else if (f2 > 0) {
            // Parent process continues here
            f3 = fork();
            if (f3 == 0) {
                // Third child process
                variavel = n1/n2;
                printf("eu sou o terceiro processo filho %d\tvariavel %d\n", getpid(), variavel);
            } else if (f3 > 0) {
                // Parent process continues here
                f4 = fork();
                if (f4 == 0) {
                    // Fourth child process
                    variavel = n1*n2;
                    printf("eu sou o quarto processo filho %d\tvariavel %d\n", getpid(), variavel);
                } else if (f4 > 0) {
                    // Parent process continues here
                    pai = getpid();
                    waitpid(f1, &status, 0); // Correct function to wait for first child
                    waitpid(f2, &status, 0); // Correct function to wait for second child
                    waitpid(f3, &status, 0); // Correct function to wait for third child
                    waitpid(f4, &status, 0); // Correct function to wait for fourth child
                    printf("eu sou o processo pai %d\tvariavel %d\n", pai, variavel);
                }
            }
        }
    }
    return 0;
}