#include <sys/types.h>
#include <sys/wait.h> // Include for waitpid
#include <unistd.h>
#include <stdio.h>

int main() {
    pid_t pai, f1, f2;
    int variavel = 5;
    int status; // Variable to store the status of the child process

    f1 = fork();
    if (!f1) {
        // First child process
        variavel *= 2;
        printf("eu sou o primeiro processo filho %d\tvariavel %d\n", getpid(), variavel);
    } else {
        // Parent process or fork failed
        f2 = fork();
        if (f2 == 0) {
            // Second child process
            variavel /= 2;
            printf("eu sou o segundo processo filho %d\tvariavel %d\n", getpid(), variavel);
        } else if (f2 > 0) {
            // Parent process continues here
            pai = getpid();
            waitpid(f1, &status, 0); // Correct function to wait for first child
            waitpid(f2, &status, 0); // Correct function to wait for second child
            printf("eu sou o processo pai %d\tvariavel %d\n", pai, variavel);
        }
    }
    return 0;
}
