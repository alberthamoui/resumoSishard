#include <sys/types.h>
#include <sys/wait.h> // Include for waitpid
#include <unistd.h>
#include <stdio.h>

int A[] = {1,2,1,4,5};
int c = 3;

int main(){
    pid_t pai;
    int status; 
    int tam = sizeof(A) / sizeof(A[0]);
    int n = tam/2;

    for (int i = 0; i<n; i++){
        pai = fork();
        if (!pai){
            int start = i*n;
            int end = start+n;
            if (i == n-1){
                end = tam;
            }
            printf("start = %d, end = %d\n", start, end);
            int contador = 0;
            for (int j = start; j<end; j++){
                if (A[j]<c){
                    contador++;
                }
            }printf("Eu sou o filho %d, com PID %d e tem %d numeros menores que C comigo\n", i, getpid(), contador);
            return 0;
        }
    }
    printf("esperando os filhos\n");
    for(int i = 0; i<n; i++){
        wait(&status);
    }
    return 0;

}