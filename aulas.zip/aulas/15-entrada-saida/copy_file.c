#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <stdio.h>

int main (int argc, char *argv[]) {
    char arq1[100] = "100a.txt"; 
    char arq2[100] = "3b.txt";
    char buf[1]; 
    char texto[100];

    int fd1 = open(arq1, O_RDONLY);
    int i = 0;
    while (read(fd1, buf, 1) > 0) {
        printf("Caracter lido: %c\n", buf[0]);
        texto[i] = buf[0];
        i++;
    }
    close(fd1);

    printf("Texto: %s\n", texto);
    if (access(arq2, F_OK) != -1) {
        char response;
        printf("File %s already exists. Overwrite it? (y/n): ", arq2);
        scanf(" %c", &response); // Read a single char response
        if (response != 'y' && response != 'Y') {
            printf("Exiting without overwriting the file.\n");
            return 0;
        }
    }


    int fd2 = open(arq2, O_WRONLY | O_CREAT, 0700);
    for (int j = 0; j < i; j++) {
        printf("Caracter escrito: %c\n", texto[j]);
        buf[0] = texto[j];
        write(fd2, buf, 1);
        //sleep(2); // só está aqui para facilitar nossa visualização. Tirar para os exercícios
    }
    close(fd2);

    return 0;
}
