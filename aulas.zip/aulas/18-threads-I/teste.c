#include <pthread.h>
#include <stdio.h>
#include <semaphore.h>
#include <stdlib.h>


// sem_t sem1, sem2;

void *thread1(void*){
    printf("A\n");
    // sem_post(&sem1);
    // sem_wait(&sem2);
    // printf("C\n");
    return NULL;
}

void *thread2(void*){
    printf("B\n");
    // sem_post(&sem2);
    // sem_wait(&sem1);
    // printf("D\n");
    return NULL;
}

void *thread3(void*){
    printf("C\n");
    return NULL;
}

void *thread4(void*){
    printf("D\n");
    return NULL;
}

void *tarefa_print_i(void *arg){
    int *i = (int*) arg;
    printf("i = %d\n", *i);
    return NULL;
}


int main(){
    int *vi = (int*) malloc(8 * sizeof(int));
    pthread_t *tids = (pthread_t*) malloc(8 * sizeof(pthread_t));
    
    if (vi == NULL) {
        fprintf(stderr, "Falha ao alocar memória para vi\n");
        return 1;
    }

    // Alocação de memória para o vetor de pthread_ts
    if (tids == NULL) {
        fprintf(stderr, "Falha ao alocar memória para tids\n");
        free(vi);  // Libera a memória já alocada para vi antes de sair
        return 1;
    }

    for (int i = 0; i < 4; i++) {
            vi[i] = i;
        }


    void* (*nomeFuncao[4])(void*) = {thread1, thread2, thread3, thread4};

    // Aqui você poderia criar threads usando pthread_create, por exemplo
    for (int i = 0; i < 4; i++) {
        pthread_create(&tids[i], NULL, nomeFuncao[i], &vi[i]);
        pthread_create(&tids[i], NULL, tarefa_print_i, &vi[i]);
    }

    // Aguardar as threads terminarem (se criadas)
    for (int i = 0; i < 4; i++) {
        pthread_join(tids[i], NULL);
    }



   // Liberando a memória alocada
    free(vi);
    free(tids);

    return 0;


}





// int main() {
//     pthread_t tid1, tid2;
//     sem_init(&sem1, 1, 0);
//     sem_init(&sem2, 1, 0);

//     pthread_create(&tid1, NULL, thread1, NULL);
//     pthread_create(&tid2, NULL, thread2, NULL);

//     pthread_join(tid1, NULL);
//     pthread_join(tid2, NULL);
    
//     return 0;
// }