#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>

int main() {
    pid_t filho;
    int status;

    filho = fork();
    if (filho == 0) {
        int i = 1/0;
        printf("Divisão por zero!\n");
    }else{
        printf("Esperando o filho!\n");
        wait(&status);
        printf("Pai acabou!\n");
        printf("Terminou normal?: %d\n", WIFEXITED(status)); // 0 ou 1
        if (WIFEXITED(status)) {
            // Mostra o valor de retorno do processo filho
            printf("Valor de retorno: %d\n", WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
            // Se o processo filho terminou por um sinal (como a divisão por zero)
            printf("Terminou por sinal: %d\n", WTERMSIG(status));
        }
    }

    return 0;
}