#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h> // Necessário para signal()



void sigint_handler(int sig) {
    printf("Processo filho recebeu SIGINT\n");
    _exit(0); // Termina o processo filho
}

int main() {
    pid_t filho;
    int status;

    filho = fork();
    if (filho == 0) {
        signal(SIGINT, sigint_handler); // Configura o manipulador de sinal para SIGINT
        printf("PID do filho: %d\n", getpid()); // Imprime o PID do processo filho
        while(1){};
        printf("Aacbou o loop!\n");
    }else{
        printf("Esperando o filho!\n");
        sleep(2); // Espera por 2 segundos antes de verificar se o processo filho ainda está executando

        // Verifica o status do processo filho sem bloquear
        int retval = waitpid(filho, &status, WNOHANG);
        if (retval == 0) {
            // Processo filho ainda está executando
            printf("Filho ainda em execução, enviando SIGKILL.\n");
            kill(filho, SIGKILL); // Envia SIGKILL ao processo filho
            waitpid(filho, &status, 0); // Espera pelo término do processo filho
        } else {
            // O processo filho já terminou
            printf("Filho já terminou antes de enviar SIGKILL.\n");
        }        printf("Pai acabou!\n");
        printf("Terminou normal?: %d\n", WIFEXITED(status)); // 0 ou 1
        if (WIFEXITED(status)) {
            // Mostra o valor de retorno do processo filho
            printf("Valor de retorno: %d\n", WEXITSTATUS(status));
        } else if (WIFSIGNALED(status)) {
            // Se o processo filho terminou por um sinal (como a divisão por zero)
            printf("Terminou por sinal: %d\n", WTERMSIG(status));
        }
    }

    return 0;
}