#include <stdio.h>     
int b=0;
int main()
{
  int i = 3/b;
  printf("fim do programa.\n");
  return 0;
}

