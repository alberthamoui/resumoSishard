
#include <stdio.h>     

int main() {
	int *px = (int*) 0x01010101;
	*px = 0;
    printf("fim do programa.\n");
    return 0;
}


