#include <stdio.h>

int main() {
    unsigned short num = -1;
    printf("Valor da variavel: %hu\n", num);
    return 0;
}