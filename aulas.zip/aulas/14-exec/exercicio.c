#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <string.h>

int main() {
    pid_t pid;
    int status;
    int state = 1;
    int n;

    while (state) {
        // printf("State: %d",state);
        printf("Qual o valor: ");
        scanf("%d", &n);
        pid = fork();
        if (!pid) {
            char numStr[20];
            sprintf(numStr, "%d", n);
            char *args[] = {"./eh_par", numStr, NULL};
            execvp("./eh_par", args);
            // fprintf(stderr, "Failed to execute './eh_par'\n");  // execvp failed
            // exit(127);  // Exit with an error code that `execvp` failed

        } else {
            waitpid(pid, &status, 0);
            if (WIFEXITED(status)) {
                int ret = WEXITSTATUS(status);
                if (ret == -1 || ret == 255) {
                    printf("Negative number encountered, stopping...\n");
                    state = 0;
                } else if (ret == 1) {
                    printf("The number %d is even.\n", n);
                } else if (ret == 0) {
                    printf("The number %d is odd.\n", n);
                }
            }
        }
    }
    return 0;
}
