#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/wait.h>
// eh_par 
int main(int argc, char *argv[]) {
    int num = atol(argv[1]);
    if (num<0){
        return -1;
    }else{
        if (num%2 == 0){
            return 0;
        }else{
            return 1;
        }
    }
}
