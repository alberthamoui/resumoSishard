#include <unistd.h>
#include <stdio.h>

int main(int argc, char *argv[]) {
    double soma = 0;
    if (argc < 2){
        printf("error, menos de 2\n");
        
    }else{
        for (int i = 0; i < argc; i++) {
            soma += atoi(argv[i]);
        }
    }printf("%f\n", soma);
    return soma;
}
