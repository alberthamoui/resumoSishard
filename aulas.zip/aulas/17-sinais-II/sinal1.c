#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <sys/types.h>

int count = 0;


void sig_handler(int num) {
    printf("Chamou Ctrl+C\n");
    count++;
    if (count == 3){
        struct sigaction handler;
        handler.sa_handler = SIG_DFL;
        handler.sa_flags = 0;
        sigemptyset(&handler.sa_mask);
        sigaction(SIGINT, &handler, NULL);
        kill(getpid(), SIGINT);
    }
}

void sigtstp_handler(int num) {
    printf("Chamou Ctrl+Z, pausando o processo...\n");
    struct sigaction handler;

    handler.sa_handler = SIG_DFL;  // Retorna ao comportamento padrão
    handler.sa_flags = 0;
    sigemptyset(&handler.sa_mask);

    sigaction(SIGTSTP, &handler, NULL);  // Aplica o manipulador padrão
    raise(SIGTSTP);  // Re-envia o sinal SIGTSTP para parar o processo
}

void sigcont_handler(int num){
    printf("Continuando!");
    // struct sigaction handler;        POR ESTAR CONTINUANDO NN PRECISA DISSO, MAS ACHO QUE PODE USAR
    // handler.sa_handler = SIG_DFL;
    // handler.sa_flag = 0;
    // sigemptyset(&handler.sa_mask);

    // sigaction(SIGCONT, &handler, NULL);
}


int main() {
    /* TODO: registre a função sig_handler
     * como handler do sinal SIGINT
     */
    struct sigaction handler_sigint, handler_sigtstp, hanlder_sigcont;

    // Configura o handler para SIGINT
    handler_sigint.sa_handler = sigint_handler;
    handler_sigint.sa_flags = 0;
    sigemptyset(&handler_sigint.sa_mask);
    sigaction(SIGINT, &handler_sigint, NULL);

    // Configura o handler para SIGTSTP
    handler_sigtstp.sa_handler = sigtstp_handler;
    handler_sigtstp.sa_flags = 0;
    sigemptyset(&handler_sigtstp.sa_mask);
    sigaction(SIGTSTP, &handler_sigtstp, NULL);

    // Configura o handler para SIGCONT
    handler_sigcont.sa_handler = sigcont_handler;
    handler_sigcont.sa_flags = 0;
    sigemptyset(&handler_sigcont.sa_mask);
    sigaction(SIGCONT, &handler_sigcont, NULL);


    printf("Meu pid: %d\n", getpid());

    while(1) {
        sleep(1);
    }
    return 0;
}
