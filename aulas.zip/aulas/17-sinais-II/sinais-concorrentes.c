#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h> // Necessário para signal()

int status = 0;

void operacao_lenta() {
    sleep(10);
}


void sigint_handler(int num) {
    struct sigaction handler_sigint;
    sigemptyset(&handler_sigint.sa_mask);
    sigaddset(&handler_sigterm.sa_mask, SIGTERM);
    handler_sigint.sa_handler = my_sigint_handler;
    handler_sigint.sa_flags = 0;

    sigaction(SIGINT, &handler_sigint, NULL);
    status += 1;
    printf("Chamou Ctrl+C; status=%d\n", status);
    operacao_lenta();
    printf("SIGINT: Vou usar status agora! status=%d\n", status);
}

void sigterm_handler(int num) {
    struct sigaction handler_sigterm;
    sigemptyset(&handler_sigterm.sa_mask);
    sigaddset(&handler_sigterm.sa_mask, SIGINT);
    handler_sigterm.sa_handler = my_sigterm_handler;
    handler_sigterm.sa_flags = 0;

    sigaction(SIGTERM, &handler_sigterm, NULL);

    status += 1;
    printf("Recebi SIGTERM; status=%d\n", status);
    operacao_lenta();
    printf("SIGTERM: Vou usar status agora! status=%d\n", status);
}

int main() {
    /* TODO: registar SIGINT aqui. */
    signal(SIGINT, sigint_handler); // Configura o manipulador de sinal para SIGINT

    /* TODO: registar SIGTERM aqui. */
    signal(SIGTERM, sigterm_handler);


    printf("Meu pid: %d\n", getpid());

    while(1) {
        sleep(1);
    }
    return 0;
}
