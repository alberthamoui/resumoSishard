#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <stdbool.h>

// C -> AB
// D -> ABEG
// F -> BEG
// H -> BEG

struct semaforos{
    sem_t *sa;
    sem_t *sb;
    sem_t *se;
    sem_t *sg;
};



// Criando as threads
void *thread1(void *_arg) {
    struct semaforos * rdv_sem = _arg;

    printf("A\n");
    sem_post(rdv_sem->sa);
    sem_post(rdv_sem->sa);

    sem_wait(rdv_sem-> sa);
    sem_wait(rdv_sem-> sb);
    printf("C\n");

    return NULL;
}

void *thread2(void *_arg) {
    struct semaforos * rdv_sem = _arg;

    printf("B\n");
    sem_post(rdv_sem->sb);
    sem_post(rdv_sem->sb);
    sem_post(rdv_sem->sb);
    sem_post(rdv_sem->sb);

    sem_wait(rdv_sem-> sa);
    sem_wait(rdv_sem-> sb);
    sem_wait(rdv_sem-> se);
    sem_wait(rdv_sem-> sg);
    printf("D\n");
    return NULL;
}

void *thread3(void *_arg) {
    struct semaforos * rdv_sem = _arg;

    printf("E\n");
    sem_post(rdv_sem->se);
    sem_post(rdv_sem->se);
    sem_post(rdv_sem->se);

    sem_wait(rdv_sem-> sb);
    sem_wait(rdv_sem-> se);
    sem_wait(rdv_sem-> sg);
    printf("F\n");
    return NULL;
}


void *thread4(void *_arg) {
    struct semaforos * rdv_sem = _arg;

    printf("G\n");
    sem_post(rdv_sem->sg);
    sem_post(rdv_sem->sg);
    sem_post(rdv_sem->sg);

    sem_wait(rdv_sem-> sb);
    sem_wait(rdv_sem-> se);
    sem_wait(rdv_sem-> sg);
    printf("H\n");
    return NULL;
}

int main(int argc, char *argv[]) {

    pthread_t t1, t2, t3, t4;
    pthread_t listaThreads[4] = {t1, t2, t3, t4};
    void *(*listaFunc[4])(void *) = {thread1, thread2, thread3, thread4};

    struct semaforos rdv_sem;
    sem_t sa, sb, se, sg;
    rdv_sem.sa = &sa;
    rdv_sem.sb = &sb;
    rdv_sem.se = &se;
    rdv_sem.sg = &sg;

    sem_init(&sa, 0, 0);
    sem_init(&sb, 0, 0);
    sem_init(&se, 0, 0);
    sem_init(&sg, 0, 0);


    for (int i = 0; i < 4; i++) {
        pthread_create(&listaThreads[i], NULL, listaFunc[i], &rdv_sem);
    }
    for (int i = 0; i < 4; i++){
        pthread_join(listaThreads[i], NULL);
    }


    // Destruindo semáforos
    sem_destroy(&sa);
    sem_destroy(&sb);
    sem_destroy(&se);
    sem_destroy(&sg);
    return 0;
}