#include <stdio.h>

int MAX_LINE_SIZE = 100;
char *proxima_linha(int fd) {
    char *linha = malloc(MAX_LINE_SIZE);
    if (linha == NULL) {
        return NULL; // Deu ruim com a memoria (nao acho q precisa)
    }

    char c;
    int index = 0;

    while (index < MAX_LINE_SIZE - 1 && read(fd, &c, 1) == 1) {
        if (c == '\n') {
            linha[index] = '\0';
            return linha;
        }
        linha[index++] = c;
    }

    if (index > 0) {  // Se foi lida alguma coisa, mesmo que não seja uma linha completa.
        linha[index] = '\0';
        return linha;
    }

    free(linha);  // Libera a memória se chegou ao fim do arquivo sem ler nada.
    return NULL;
}

int main() {

    return 0;
}
